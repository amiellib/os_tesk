#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <sched.h>
#include <linux/sched.h>
#include <sys/types.h>
// for SCHED_DEADLINE to work i need this info added
struct sched_attr {
    uint32_t size;
    uint32_t sched_policy;
    uint64_t sched_flags;
    /* SCHED_NORMAL, SCHED_BATCH */
    int32_t sched_nice;
    /* SCHED_FIFO, SCHED_RR */
    uint32_t sched_priority;
    /* SCHED_DEADLINE (nsec) */
    uint64_t sched_runtime;
    uint64_t sched_deadline;
    uint64_t sched_period;
};
// for SCHED_DEADLINE exrta info it needed
int sched_setattr(pid_t pid, const struct sched_attr *attr, unsigned int flags)
{
   return syscall(__NR_sched_setattr, pid, attr, flags);
}
 int main(int argc, char* argv[]) {
   int priority=atoi(argv[2]);
   int policy=atoi(argv[1]);
   // to see the process id
   pid_t pid = getpid();
   printf("pid is: %d\n", pid);
   // change priority on the struct as i got from user
   const struct sched_param attr_param = {
       .sched_priority = priority
   };
   // deadline only worked for me if it was hardcoded the exra info it needed
   if (policy != 6)
   {
     sched_setscheduler(0, policy, &attr_param);
   } else
   {
     struct sched_attr attr = {
        .size = sizeof(attr),
        .sched_priority = priority ,
        .sched_policy = SCHED_DEADLINE,
        .sched_runtime = 40000000,
        .sched_period = 150000000,
        .sched_deadline = 120000000
    };
    pid_t tid = syscall(SYS_gettid);
    if (sched_setattr(tid, &attr, 0))
        perror("sched_setattr()");
   }
   // keep process running to make sure it worked
   while(1){
     sleep(2);
   };
   return 0;
 }
