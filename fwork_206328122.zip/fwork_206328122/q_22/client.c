#include <stdio.h>

int main(int argc,char*  argv[])
{
   int i,send_num,times_to_run=atoi(argv[3]);
//send the signel to server from the info i got in bash
for(i=0;i<times_to_run;++i)
{
send_num=kill(atoi(argv[1]),atoi(argv[2]));
}
return (0);
}