#include <stdio.h>
#include  <unistd.h>
#include  <signal.h>


void handler_sigint(int );
void handler_siguser1(int );
//counter to see how many i got
int counter_sigint=0;


int main()
{
//to see what is the server pid is
pid_t pid=getpid();
printf("pid of the server is %d \n",pid);
//make the handler work
signal(SIGINT,handler_sigint);
signal(SIGUSR1,handler_siguser1);
//to check the code work i keep the prosses alive
while(1)
{
	sleep(1);
}
return (0);
}
//count the SIGINT 
void handler_sigint(int signum)
{
	++counter_sigint;
}
//print the number of counted SIGINT 
void handler_siguser1(int signum)
{
	printf("%d \n",counter_sigint);
}