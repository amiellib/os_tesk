#include <sys/types.h>
#include <signal.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
int main(int argc, char* argv[])
{
int pid,number;
pid=atoi(argv[1]);
number=kill(pid,1);
if(number !=0)
switch(errno)
{
case EPERM:
printf("Process %s exsis but we have no permission.\n",argv[1]);
break;
case ESRCH:
printf("Process %s does not exsit.\n",argv[1]);
break;
}
else
printf("Process %s exsits \n",argv[1]);
return 0;
}
