#define _BSD_SOURCE
#include <stdio.h>
#include <stdlib.h>

char globBuf[65536];            /* 1.Bss global  Uninitialized data */
int primes[] = { 2, 3, 5, 7 };  /* 2. Initialized data    data global */

static int
square(int x)                   /* 3. Square frame �global-data */
{
    int result;                 /* 4. Square frame �global-data */

    result = x * x;
    return result;              /* 5. register */
}

static void
doCalc(int val)                 /* 6.Local frame text  */
{
    printf("The square of %d is %d\n", val, square(val));

    if (val < 1000) {
        int t;                  /* 7.frame of docalc */

        t = val * val * val;
        printf("The cube of %d is %d\n", val, t);
    }
}

int
main(int argc, char* argv[]) /*8 Global frame text of main */
{
    static int key = 9973;      /*9 Initialized dada segment-local-data */
    static char mbuf[10240000]; /*10 Uninitialized data-bss local */
    char* p;                    /*11 Frame of main Uninitialized */


    doCalc(key);

    exit(EXIT_SUCCESS);
}