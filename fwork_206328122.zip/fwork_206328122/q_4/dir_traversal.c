#define _XOPEN_SOURCE 500
#include <sys/types.h>
#include <ftw.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <sys/stat.h>

struct stat inode;
static int
display_info(const char* fpath, const struct stat* sb,
    int tflag, struct FTW* ftwbuf)
{
    lstat(fpath, &inode);
    if (!S_ISLNK(inode.st_mode))
    {
        printf("%-3s %-7ld  %-12s   \n",
            (tflag == FTW_D) ? "D" : (tflag == FTW_DNR) ? "DNR" :
            (tflag == FTW_DP) ? "DP" : (tflag == FTW_F) ? "F" :
            (tflag == FTW_NS) ? "NS" : "???",
            (long)inode.st_ino, fpath + ftwbuf->base);
    }
    return 0;           /* To tell nftw() to continue */
}
int main(int argc, char* argv[])
{
    int flags = 0;
    if (argc > 2 && strchr(argv[2], 'd') != NULL)
        flags |= FTW_DEPTH;
    if (argc > 2 && strchr(argv[2], 'p') != NULL)
        flags |= FTW_PHYS;
    if (nftw((argc < 2) ? "." : argv[1], display_info, 20, flags) == -1) {
        perror("nftw");
        exit(EXIT_FAILURE);
    }
    exit(EXIT_SUCCESS);
}
